import sys
import pymysql
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QApplication, QMainWindow, QDialog, QMessageBox, QTableWidgetItem
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import QRegExpValidator
from PyQt5.QtCore import QRegExp



class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        loadUi('main_window.ui', self)

        self.connection = None
        self.main_connect.clicked.connect(self.connect_to_database)

    def connect_to_database(self):
        host = self.main_text_host.text()
        user = self.main_text_user.text()
        password = self.main_text_pass.text()

        try:
            self.connection = pymysql.connect(
                host=host,
                user=user,
                password=password,
                database='todomail_sig'
            )

            QMessageBox.information(self, "Conectado", "Conexión exitosa.")

            self.menu_window = MenuWindow(self.connection)
            self.menu_window.show()
            self.hide()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


class MenuWindow(QDialog):
    def __init__(self, connection):
        super().__init__()
        loadUi('menu.ui', self)

        self.connection = connection

        self.cargar_tablas()

        self.ir_menu.clicked.connect(self.ir_tabla)
        self.salir_menu.clicked.connect(self.cerrar)

    def cargar_tablas(self):
        tablas_permitidas = ["campanias", "clientes", "interacciones","transacciones"]
        self.lista_tablas.clear()

        for t in tablas_permitidas:
            self.lista_tablas.addItem(t)
        

    def ir_tabla(self):
        tabla = self.lista_tablas.currentText()

        if tabla == "campanias":
            self.v = CampaniasWindow(self.connection)
            self.v.show()

        elif tabla == "clientes":
            self.r = ClientesWindow(self.connection)
            self.r.show()

        elif tabla == "interacciones":
            self.p = InteraccionesWindow(self.connection)
            self.p.show()
        elif tabla == 'transacciones':
            self.p = TransaccionesWindow(self.connection)
            self.p.show()

    def cerrar(self):
        self.connection.close()
        QApplication.quit()


class VuelosWindow(QDialog):
    def __init__(self, connection):
        super().__init__()
        loadUi('alo.ui', self)

        self.connection = connection
        self.ver_vuelos.clicked.connect(self.cargar_vuelos)

    def cargar_vuelos(self):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT * FROM campanias")
                resultados = cursor.fetchall()
                columnas = [col[0] for col in cursor.description]

                self.tabla_vuelos.setRowCount(len(resultados))
                self.tabla_vuelos.setColumnCount(len(columnas))
                self.tabla_vuelos.setHorizontalHeaderLabels(columnas)

                for fila, datos in enumerate(resultados):
                    for col, valor in enumerate(datos):
                        self.tabla_vuelos.setItem(fila, col, QTableWidgetItem(str(valor)))

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))



class CampaniasWindow(QDialog):
    def __init__(self, connection):
        super().__init__()
        loadUi('campanias.ui', self)

        self.connection = connection

        # conexiones
        self.ver_campania.clicked.connect(self.cargar_campanias)
        self.agregar_campania.clicked.connect(self.agregar_campania_func)
        self.editar_campania.clicked.connect(self.editar_campania_func)
        self.eliminar_campania.clicked.connect(self.eliminar_campania_func)

        # cuando seleccionas una fila → cargar datos en los lineEdit
        self.tabla_campanias.itemSelectionChanged.connect(self.cargar_datos_formulario)


    # ============================================================
    #                 CARGAR TABLA
    # ============================================================
    def cargar_campanias(self):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT * FROM campanias")
                resultados = cursor.fetchall()
                columnas = [c[0] for c in cursor.description]

                self.tabla_campanias.setRowCount(len(resultados))
                self.tabla_campanias.setColumnCount(len(columnas))
                self.tabla_campanias.setHorizontalHeaderLabels(columnas)

                for row, data in enumerate(resultados):
                    for col, value in enumerate(data):
                        self.tabla_campanias.setItem(row, col, QTableWidgetItem(str(value)))

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))



    # ============================================================
    #            CARGAR FORMULARIO DESDE LA TABLA
    # ============================================================
    def cargar_datos_formulario(self):
        
        fila = self.tabla_campanias.currentRow()
        if fila == -1:
            return

        self.clienteid.setText(self.tabla_campanias.item(fila, 1).text())
        self.planid.setCurrentText(self.tabla_campanias.item(fila, 2).text())

        fecha_env = self.tabla_campanias.item(fila, 3).text()
        self.fechaenvio.setDateTime(QDateTime.fromString(fecha_env, "yyyy-MM-dd HH:mm:ss"))

        self.tiposerv.setText(self.tabla_campanias.item(fila, 4).text())
        self.estadocamp.setCurrentText(self.tabla_campanias.item(fila, 5).text())

        self.tasaap.setText(self.tabla_campanias.item(fila, 6).text())
        self.tasac.setText(self.tabla_campanias.item(fila, 7).text())

        self.dest.setText(self.tabla_campanias.item(fila, 8).text())
        self.asuntocam.setText(self.tabla_campanias.item(fila, 9).text())

        fecha_crea = self.tabla_campanias.item(fila, 10).text()
        self.fechacrea.setDateTime(QDateTime.fromString(fecha_crea, "yyyy-MM-dd HH:mm:ss"))



    # ============================================================
    #                  AGREGAR CAMPAÑA
    # ============================================================
    def agregar_campania_func(self):

        cliente_id = self.clienteid.text()
        plan_id_txt = self.planid.currentText()
        tipo_serv = self.tiposerv.text()
        estado = self.estadocamp.currentText()
        tasa_ap = self.tasaap.text()
        tasa_clicks = self.tasac.text()
        destinatarios = self.dest.text()
        asunto = self.asuntocam.text()

        fecha_envio = self.fechaenvio.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        fecha_creacion = self.fechacrea.dateTime().toString("yyyy-MM-dd HH:mm:ss")

        # VALIDACIONES
        if plan_id_txt == "Seleccione un plan":
            QMessageBox.warning(self, "Error", "Debe seleccionar un plan.")
            return
        
        if estado == "Estado de campaña":
            QMessageBox.warning(self, "Error", "Debe seleccionar el estado de la campaña.")
            return

        if not destinatarios.isdigit():
            QMessageBox.warning(self, "Error", "Destinatarios enviados debe ser un número.")
            return

        plan_id = int(plan_id_txt)
        destinatarios = int(destinatarios)

        try:
            with self.connection.cursor() as cursor:
                query = """
                INSERT INTO campanias 
                (cliente_id, plan_id, fecha_envio, tipo_servicio, estado_campania,
                tasa_apertura, tasa_clics, destinatarios_enviados,
                asunto_campania, fecha_creacion)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """

                cursor.execute(query, (
                    cliente_id, plan_id, fecha_envio, tipo_serv, estado,
                    tasa_ap, tasa_clicks, destinatarios, asunto, fecha_creacion
                ))

                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Campaña agregada.")
            self.cargar_campanias()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))



    # ============================================================
    #                  EDITAR CAMPAÑA
    # ============================================================
    def editar_campania_func(self):
        fila = self.tabla_campanias.currentRow()
        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione una campaña.")
            return

        campania_id = self.tabla_campanias.item(fila, 0).text()

        cliente_id = self.clienteid.text()
        plan_id_txt = self.planid.currentText()
        tipo_serv = self.tiposerv.text()
        estado = self.estadocamp.currentText()
        tasa_ap = self.tasaap.text()
        tasa_clicks = self.tasac.text()
        destinatarios = self.dest.text()
        asunto = self.asuntocam.text()

        fecha_envio = self.fechaenvio.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        fecha_creacion = self.fechacrea.dateTime().toString("yyyy-MM-dd HH:mm:ss")

        # Validaciones
        if plan_id_txt == "Seleccione un plan":
            QMessageBox.warning(self, "Error", "Debe seleccionar un plan.")
            return
        
        if estado == "Estado de campaña":
            QMessageBox.warning(self, "Error", "Debe seleccionar el estado de la campaña.")
            return

        if not destinatarios.isdigit():
            QMessageBox.warning(self, "Error", "Destinatarios enviados debe ser numérico.")
            return

        plan_id = int(plan_id_txt)
        destinatarios = int(destinatarios)

        try:
            with self.connection.cursor() as cursor:
                query = """
                UPDATE campanias
                SET cliente_id=%s, plan_id=%s, fecha_envio=%s,
                    tipo_servicio=%s, estado_campania=%s,
                    tasa_apertura=%s, tasa_clics=%s,
                    destinatarios_enviados=%s, asunto_campania=%s,
                    fecha_creacion=%s
                WHERE campania_id=%s
                """

                cursor.execute(query, (
                    cliente_id, plan_id, fecha_envio, tipo_serv, estado,
                    tasa_ap, tasa_clicks, destinatarios, asunto,
                    fecha_creacion, campania_id
                ))

                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Campaña editada.")
            self.cargar_campanias()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


    # ============================================================
    #                  ELIMINAR CAMPAÑA
    # ============================================================
    def eliminar_campania_func(self):
        fila = self.tabla_campanias.currentRow()
        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione una campaña.")
            return

        campania_id = self.tabla_campanias.item(fila, 0).text()

        try:
            with self.connection.cursor() as cursor:
                cursor.execute("DELETE FROM campanias WHERE campania_id=%s", (campania_id,))
                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Campaña eliminada.")
            self.cargar_campanias()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

class ClientesWindow(QDialog):
    def __init__(self, connection):
        super().__init__()
        loadUi("clientes.ui", self)

        self.connection = connection

        # Conexiones
        self.ver_clientes.clicked.connect(self.cargar_clientes)
        self.agregar_cliente.clicked.connect(self.agregar_cliente_func)
        self.editar_cliente.clicked.connect(self.editar_cliente_func)
        self.eliminar_cliente.clicked.connect(self.eliminar_cliente_func)

        # Cuando seleccionas una fila -> se carga al formulario
        self.tabla_clientes.itemSelectionChanged.connect(self.cargar_datos_formulario)

        # VALIDADORES
        self.configurar_validadores()

    # =====================================================
    #                   VALIDADORES
    # =====================================================
    def configurar_validadores(self):
        # Teléfono: formato +569XXXXXXXX
        telefono_regex = QRegExp(r"^\+569\d{8}$")
        self.telf.setValidator(QRegExpValidator(telefono_regex))

        # Email básico
        email_regex = QRegExp(r"^[\w\.-]+@[\w\.-]+\.\w+$")
        self.emaill.setValidator(QRegExpValidator(email_regex))

        # RUT chileno (simple validación)
        rut_regex = QRegExp(r"^\d{7,8}-[\dkK]$")
        self.rutt.setValidator(QRegExpValidator(rut_regex))

    # =====================================================
    #               CARGAR TABLA CLIENTES
    # =====================================================
    def cargar_clientes(self):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT * FROM clientes")
                resultados = cursor.fetchall()
                columnas = [c[0] for c in cursor.description]

                self.tabla_clientes.setRowCount(len(resultados))
                self.tabla_clientes.setColumnCount(len(columnas))
                self.tabla_clientes.setHorizontalHeaderLabels(columnas)

                for fila, datos in enumerate(resultados):
                    for col, valor in enumerate(datos):
                        self.tabla_clientes.setItem(fila, col, QTableWidgetItem(str(valor)))

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # =====================================================
    #              CARGAR DATOS AL FORMULARIO
    # =====================================================
    def cargar_datos_formulario(self):
        fila = self.tabla_clientes.currentRow()
        if fila == -1:
            return

        self.rutt.setText(self.tabla_clientes.item(fila, 1).text())
        self.Nombre_comp.setText(self.tabla_clientes.item(fila, 2).text())
        self.emaill.setText(self.tabla_clientes.item(fila, 3).text())
        self.telf.setText(self.tabla_clientes.item(fila, 4).text())
        self.rubro.setText(self.tabla_clientes.item(fila, 5).text())

        # fecha primer contacto
        fecha_pc = self.tabla_clientes.item(fila, 6).text()
        self.fecha1.setDate(QDate.fromString(fecha_pc, "yyyy-MM-dd"))

        self.canalad.setText(self.tabla_clientes.item(fila, 7).text())
        self.estadocl.setCurrentText(self.tabla_clientes.item(fila, 8).text())

        # fechas automáticas
        fecha_cre = self.tabla_clientes.item(fila, 9).text()
        self.fechacr.setDateTime(QDateTime.fromString(fecha_cre, "yyyy-MM-dd HH:mm:ss"))

        fecha_act = self.tabla_clientes.item(fila, 10).text()
        self.fechaact.setDateTime(QDateTime.fromString(fecha_act, "yyyy-MM-dd HH:mm:ss"))

    # =====================================================
    #                   AGREGAR CLIENTE
    # =====================================================
    def agregar_cliente_func(self):

        rut = self.rutt.text()
        nombre = self.Nombre_comp.text()
        email = self.emaill.text()
        telefono = self.telf.text()
        rubro = self.rubro.text()
        fecha_pc = self.fecha1.date().toString("yyyy-MM-dd")
        canal = self.canalad.text()
        estado = self.estadocl.currentText()
        fecha_cre = self.fechacr.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        fecha_act = self.fechaact.dateTime().toString("yyyy-MM-dd HH:mm:ss")

        if not rut or not nombre or not email or not telefono or not canal:
            QMessageBox.warning(self, "Error", "Debe completar todos los campos obligatorios.")
            return

        try:
            with self.connection.cursor() as cursor:
                query = """
                INSERT INTO clientes 
                (rut, nombre_completo, email, telefono, empresa_rubro,
                 fecha_primer_contacto, canal_adquisicion, estado,
                 fecha_creacion, fecha_actualizacion)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """

                cursor.execute(query, (
                    rut, nombre, email, telefono, rubro,
                    fecha_pc, canal, estado, fecha_cre, fecha_act
                ))

                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Cliente agregado.")
            self.cargar_clientes()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # =====================================================
    #                   EDITAR CLIENTE
    # =====================================================
    def editar_cliente_func(self):
        fila = self.tabla_clientes.currentRow()
        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione un cliente.")
            return

        cliente_id = self.tabla_clientes.item(fila, 0).text()

        rut = self.rutt.text()
        nombre = self.Nombre_comp.text()
        email = self.emaill.text()
        telefono = self.telf.text()
        rubro = self.rubro.text()
        fecha_pc = self.fecha1.date().toString("yyyy-MM-dd")
        canal = self.canalad.text()
        estado = self.estadocl.currentText()
        fecha_cre = self.fechacr.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        fecha_act = self.fechaact.dateTime().toString("yyyy-MM-dd HH:mm:ss")

        try:
            with self.connection.cursor() as cursor:
                query = """
                UPDATE clientes
                SET rut=%s, nombre_completo=%s, email=%s, telefono=%s,
                    empresa_rubro=%s, fecha_primer_contacto=%s,
                    canal_adquisicion=%s, estado=%s,
                    fecha_creacion=%s, fecha_actualizacion=%s
                WHERE cliente_id=%s
                """

                cursor.execute(query, (
                    rut, nombre, email, telefono, rubro,
                    fecha_pc, canal, estado, fecha_cre, fecha_act,
                    cliente_id
                ))

                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Cliente editado.")
            self.cargar_clientes()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # =====================================================
    #                  ELIMINAR CLIENTE
    # =====================================================
    def eliminar_cliente_func(self):
        fila = self.tabla_clientes.currentRow()
        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione un cliente.")
            return

        cliente_id = self.tabla_clientes.item(fila, 0).text()

        try:
            with self.connection.cursor() as cursor:
                cursor.execute("DELETE FROM clientes WHERE cliente_id=%s", (cliente_id,))
                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Cliente eliminado.")
            self.cargar_clientes()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

class InteraccionesWindow(QDialog):
    def __init__(self, connection):
        super().__init__()
        loadUi("interacciones.ui", self)

        self.connection = connection

        # Conectar botones
        self.ver_inter.clicked.connect(self.cargar_interacciones)
        self.agregar_inter.clicked.connect(self.agregar_interaccion)
        self.editar_inter.clicked.connect(self.editar_interaccion)
        self.eliminar_inter.clicked.connect(self.eliminar_interaccion)

        # Cuando se seleccione una fila se rellena el formulario
        self.tabla_interacciones.itemSelectionChanged.connect(self.cargar_datos_formulario)

    # ================================================
    #               VER INTERACCIONES
    # ================================================
    def cargar_interacciones(self):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT * FROM interacciones")
                resultados = cursor.fetchall()
                columnas = [c[0] for c in cursor.description]

                self.tabla_interacciones.setRowCount(len(resultados))
                self.tabla_interacciones.setColumnCount(len(columnas))
                self.tabla_interacciones.setHorizontalHeaderLabels(columnas)

                for fila, datos in enumerate(resultados):
                    for col, valor in enumerate(datos):
                        self.tabla_interacciones.setItem(fila, col, QTableWidgetItem(str(valor)))

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # ================================================
    #     CARGAR FORMULARIO DESDE LA TABLA
    # ================================================
    def cargar_datos_formulario(self):
        fila = self.tabla_interacciones.currentRow()
        if fila == -1:
            return

        self.clienteid.setText(self.tabla_interacciones.item(fila, 1).text())

        fecha_inter = self.tabla_interacciones.item(fila, 2).text()
        self.fechacrr.setDateTime(QDateTime.fromString(fecha_inter, "yyyy-MM-dd HH:mm:ss"))

        self.tipoint.setText(self.tabla_interacciones.item(fila, 3).text())
        self.desc.setText(self.tabla_interacciones.item(fila, 4).text())
        self.mediocon.setText(self.tabla_interacciones.item(fila, 5).text())
        self.resp.setText(self.tabla_interacciones.item(fila, 6).text())

        fecha_crea = self.tabla_interacciones.item(fila, 7).text()
        self.fechaint.setDateTime(QDateTime.fromString(fecha_crea, "yyyy-MM-dd HH:mm:ss"))

    # ================================================
    #               AGREGAR INTERACCIÓN
    # ================================================
    def agregar_interaccion(self):

        cliente_id = self.clienteid.text()
        fecha_inter = self.fechacrr.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        tipo = self.tipoint.text()
        descripcion = self.desc.text()
        medio = self.mediocon.text()
        responsable = self.resp.text()
        fecha_creacion = self.fechaint.dateTime().toString("yyyy-MM-dd HH:mm:ss")

        # Validaciones
        if not cliente_id.isdigit():
            QMessageBox.warning(self, "Error", "cliente_id debe ser un número.")
            return

        try:
            with self.connection.cursor() as cursor:
                query = """
                INSERT INTO interacciones 
                (cliente_id, fecha_interaccion, tipo_interaccion,
                 descripcion, medio_contacto, responsable, fecha_creacion)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                """

                cursor.execute(query, (
                    cliente_id, fecha_inter, tipo,
                    descripcion, medio, responsable, fecha_creacion
                ))

                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Interacción agregada.")
            self.cargar_interacciones()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # ================================================
    #               EDITAR INTERACCIÓN
    # ================================================
    def editar_interaccion(self):
        fila = self.tabla_interacciones.currentRow()
        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione una interacción.")
            return

        interaccion_id = self.tabla_interacciones.item(fila, 0).text()

        cliente_id = self.clienteid.text()
        fecha_inter = self.fechacrr.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        tipo = self.tipoint.text()
        descripcion = self.desc.text()
        medio = self.mediocon.text()
        responsable = self.resp.text()
        fecha_creacion = self.fechaint.dateTime().toString("yyyy-MM-dd HH:mm:ss")

        if not cliente_id.isdigit():
            QMessageBox.warning(self, "Error", "cliente_id debe ser numérico.")
            return

        try:
            with self.connection.cursor() as cursor:
                query = """
                UPDATE interacciones
                SET cliente_id=%s, fecha_interaccion=%s, tipo_interaccion=%s,
                    descripcion=%s, medio_contacto=%s, responsable=%s,
                    fecha_creacion=%s
                WHERE interaccion_id=%s
                """

                cursor.execute(query, (
                    cliente_id, fecha_inter, tipo,
                    descripcion, medio, responsable, fecha_creacion,
                    interaccion_id
                ))

                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Interacción editada.")
            self.cargar_interacciones()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # ================================================
    #               ELIMINAR
    # ================================================
    def eliminar_interaccion(self):
        fila = self.tabla_interacciones.currentRow()
        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione una interacción.")
            return

        interaccion_id = self.tabla_interacciones.item(fila, 0).text()

        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    "DELETE FROM interacciones WHERE interaccion_id=%s",
                    (interaccion_id,)
                )
                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Interacción eliminada.")
            self.cargar_interacciones()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))


class TransaccionesWindow(QDialog):
    def __init__(self, connection):
        super().__init__()
        loadUi("transacciones.ui", self)

        self.connection = connection

        # conexiones de botones
        self.ver_tran.clicked.connect(self.cargar_transacciones)
        self.agregar_tran.clicked.connect(self.agregar_transaccion)
        self.editar_tran.clicked.connect(self.editar_transaccion)
        self.eliminar_tran.clicked.connect(self.eliminar_transaccion)

        self.tabla_transacciones.itemSelectionChanged.connect(self.cargar_datos_formulario)

    # ==========================================================
    #                 CARGAR TABLA
    # ==========================================================
    def cargar_transacciones(self):
        try:
            with self.connection.cursor() as cursor:
                cursor.execute("SELECT * FROM transacciones")
                datos = cursor.fetchall()
                columnas = [c[0] for c in cursor.description]

                self.tabla_transacciones.setRowCount(len(datos))
                self.tabla_transacciones.setColumnCount(len(columnas))
                self.tabla_transacciones.setHorizontalHeaderLabels(columnas)

                for fila, fila_datos in enumerate(datos):
                    for col, valor in enumerate(fila_datos):
                        self.tabla_transacciones.setItem(
                            fila, col, QTableWidgetItem(str(valor))
                        )

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # ==========================================================
    #             CARGAR FORMULARIO DESDE TABLA
    # ==========================================================
    def cargar_datos_formulario(self):
        fila = self.tabla_transacciones.currentRow()
        if fila == -1:
            return

        self.clienteid.setText(self.tabla_transacciones.item(fila, 1).text())

        fecha_tran = self.tabla_transacciones.item(fila, 2).text()
        self.fechatran.setDateTime(QDateTime.fromString(fecha_tran, "yyyy-MM-dd HH:mm:ss"))

        self.montotran.setText(self.tabla_transacciones.item(fila, 3).text())
        self.tiposerv.setText(self.tabla_transacciones.item(fila, 4).text())
        self.descc.setText(self.tabla_transacciones.item(fila, 5).text())
        self.estadopa.setCurrentText(self.tabla_transacciones.item(fila, 6).text())

        fecha_cre = self.tabla_transacciones.item(fila, 7).text()
        self.fechacrrr.setDateTime(QDateTime.fromString(fecha_cre, "yyyy-MM-dd HH:mm:ss"))

    # ==========================================================
    #                 AGREGAR TRANSACCIÓN
    # ==========================================================
    def agregar_transaccion(self):

        cliente_id = self.clienteid.text()
        fecha_trans = self.fechatran.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        monto = self.montotran.text()
        tipo_serv = self.tiposerv.text()
        descripcion = self.descc.text()
        estado_pago = self.estadopa.currentText()
        fecha_creacion = self.fechacrrr.dateTime().toString("yyyy-MM-dd HH:mm:ss")

        # VALIDACIONES
        if not cliente_id.isdigit():
            QMessageBox.warning(self, "Error", "cliente_id debe ser un número.")
            return

        try:
            monto_float = float(monto)
        except:
            QMessageBox.warning(self, "Error", "El monto debe ser numérico.")
            return
        

        if estado_pago == "Estado del pago":
            QMessageBox.warning(self, "Error", "Debe seleccionar el estado del pago.")
            return

        try:
            with self.connection.cursor() as cursor:
                query = """
                INSERT INTO transacciones
                (cliente_id, fecha_transaccion, monto, tipo_servicio,
                 descripcion, estado_pago, fecha_creacion)
                VALUES (%s, %s, %s, %s, %s, %s, %s)
                """

                cursor.execute(query, (
                    cliente_id, fecha_trans, monto_float, tipo_serv,
                    descripcion, estado_pago, fecha_creacion
                ))

                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Transacción agregada.")
            self.cargar_transacciones()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # ==========================================================
    #                  EDITAR TRANSACCIÓN
    # ==========================================================
    def editar_transaccion(self):
        fila = self.tabla_transacciones.currentRow()
        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione una transacción.")
            return

        transaccion_id = self.tabla_transacciones.item(fila, 0).text()

        cliente_id = self.clienteid.text()
        fecha_trans = self.fechatran.dateTime().toString("yyyy-MM-dd HH:mm:ss")
        monto = self.montotran.text()
        tipo_serv = self.tiposerv.text()
        descripcion = self.descc.text()
        estado_pago = self.estadopa.currentText()
        fecha_creacion = self.fechacrrr.dateTime().toString("yyyy-MM-dd HH:mm:ss")

        # VALIDACIONES
        if not cliente_id.isdigit():
            QMessageBox.warning(self, "Error", "cliente_id debe ser numérico.")
            return

        try:
            monto_float = float(monto)
        except:
            QMessageBox.warning(self, "Error", "Monto debe ser numérico.")
            return
        
        if estado_pago == "Estado del pago":
            QMessageBox.warning(self, "Error", "Debe seleccionar el estado del pago.")
            return

        try:
            with self.connection.cursor() as cursor:
                query = """
                UPDATE transacciones
                SET cliente_id=%s, fecha_transaccion=%s, monto=%s,
                    tipo_servicio=%s, descripcion=%s, estado_pago=%s,
                    fecha_creacion=%s
                WHERE transaccion_id=%s
                """

                cursor.execute(query, (
                    cliente_id, fecha_trans, monto_float,
                    tipo_serv, descripcion, estado_pago,
                    fecha_creacion, transaccion_id
                ))

                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Transacción editada.")
            self.cargar_transacciones()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    # ==========================================================
    #                  ELIMINAR TRANSACCIÓN
    # ==========================================================
    def eliminar_transaccion(self):
        fila = self.tabla_transacciones.currentRow()
        if fila == -1:
            QMessageBox.warning(self, "Error", "Seleccione una transacción.")
            return

        transaccion_id = self.tabla_transacciones.item(fila, 0).text()

        try:
            with self.connection.cursor() as cursor:
                cursor.execute(
                    "DELETE FROM transacciones WHERE transaccion_id=%s",
                    (transaccion_id,)
                )
                self.connection.commit()

            QMessageBox.information(self, "Éxito", "Transacción eliminada.")
            self.cargar_transacciones()

        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))






if __name__ == '__main__':
    app = QApplication(sys.argv)
    ventana = MainWindow()
    ventana.show()
    sys.exit(app.exec_())

